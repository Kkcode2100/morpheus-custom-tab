alert("hellow from plugin");

console.log("Script loaded from Global UI Plugin");
